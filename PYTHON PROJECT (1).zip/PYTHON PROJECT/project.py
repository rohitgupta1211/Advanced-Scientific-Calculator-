import tkinter as tk
from tkinter import messagebox
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

memory = 0  # Variable to store memory value

def on_click(button_text):
    global memory
    
    # Clear all or one character
    if button_text == "C":
        entry_var.set("")
    elif button_text == "CE":
        entry_var.set(entry_var.get()[:-1])

    # Calculate result
    elif button_text == "=":
        try:
            result = eval(entry_var.get())
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Expression")
    
    # Trigonometric calculations
    elif button_text == "sin":
        try:
            result = math.sin(math.radians(float(entry_var.get())))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Sine")
    elif button_text == "cos":
        try:
            result = math.cos(math.radians(float(entry_var.get())))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Cosine")
    elif button_text == "tan":
        try:
            result = math.tan(math.radians(float(entry_var.get())))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Tangent")
    elif button_text == "cosec":
        try:
            value = float(entry_var.get())
            if value % 180 == 0:
                raise ValueError
            result = 1 / math.sin(math.radians(value))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Cosecant")
    elif button_text == "sec":
        try:
            value = float(entry_var.get())
            if value % 90 == 0 and value % 180 != 0:
                raise ValueError
            result = 1 / math.cos(math.radians(value))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Secant")
    elif button_text == "cot":
        try:
            value = float(entry_var.get())
            if value % 180 == 0:
                raise ValueError
            result = 1 / math.tan(math.radians(value))
            entry_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid Input for Cotangent")
    elif button_text == "Plot Graph":
        plot_graph()
    else:
        entry_var.set(entry_var.get() + button_text)
    
    # Move cursor to the rightmost position
    entry.icursor(tk.END)

def plot_graph():
    try:
        expr = entry_var.get()
        x = np.linspace(-360, 360, 400)
        y = [eval(expr, {"x": val, "sin": math.sin, "cos": math.cos, "tan": math.tan, "math": math, "radians": math.radians}) for val in x]
        
        fig, ax = plt.subplots()
        ax.plot(x, y, label=f"y = {expr}")
        ax.axhline(0, color='black', linewidth=0.5)
        ax.axvline(0, color='black', linewidth=0.5)
        ax.legend()
        plt.xlabel("X values")
        plt.ylabel("Function values")
        plt.title("Graph Plot")
        plt.grid()
        
        plt.show()
    except Exception:
        messagebox.showerror("Error", "Invalid Expression for Graph Plotting")

# Creating main window
root = tk.Tk()
root.title("Advanced Scientific Calculator")
root.geometry("450x700")
root.resizable(False, False)

# Entry widget to display expression
entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=("Arial", 18), bd=10, relief=tk.SUNKEN, justify="right")
entry.pack(fill="both", ipadx=8, padx=10, pady=10)

# Buttons layout
buttons = [
    ['7', '8', '9', '/', 'M+'],
    ['4', '5', '6', '*', 'MR'],
    ['1', '2', '3', '-', 'π'],
    ['C', 'CE', '0', '=', '+'],
    ['x²', '√x', 'x³', '∛x', '%'],
    ['sin', 'cos', 'tan', 'cosec', 'sec'],
    ['cot', 'log', 'ln', 'exp', '!'],
    ['Bin', 'Hex', 'Dec', '(', ')'],
    ['Plot Graph']
]

button_frame = tk.Frame(root)
button_frame.pack(fill="both", expand=True)

for row in buttons:
    frame_row = tk.Frame(button_frame)
    frame_row.pack(fill="both", expand=True)
    for btn_text in row:
        if btn_text:  # Skip empty strings
            button = tk.Button(frame_row, text=btn_text, font=("Arial", 16), height=2, width=6,
                               command=lambda b=btn_text: on_click(b))
            button.pack(side="left", expand=True, fill="both")

# Run the Tkinter event loop
root.mainloop()
